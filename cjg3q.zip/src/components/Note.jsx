import React from "react";

function Note() {
  return (
   <div className="note">
     <h1>Javascript and React.js</h1>
     <p>This was an amazing bootcamp taken up by Shauray Sinha We covered everthing from Scratch including Javascript React.js, HTML. And by these bootcamp i have learn a lots of things.</p>
   </div>
  );
}

export default Note;
